<?php

require __DIR__ . '/../public/index.php';
