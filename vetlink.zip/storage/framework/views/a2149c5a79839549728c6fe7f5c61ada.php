<div x-data="{ open: false }" class="relative flex p-2 ml-4 mb-2 mx-auto cursor-pointer">
    <div @click="open = !open" class="flex items-center">
        <svg viewBox="0 0 24 24" fill="none" class="w-6 h-6">
            <!-- Icon content -->
        </svg>
        <h3 class="ml-3 text-white">Clients</h3>
        <svg :class="{ 'rotate-180': open }" class="w-6 h-6 ml-2 transform transition-transform" fill="none">
            <!-- Arrow Icon -->
        </svg>
    </div>

    <!-- Dropdown Menu -->
    <div x-show="open" @click.away="open = false"
        class="absolute bg-primary text-white rounded shadow-lg mt-2 left-0 w-40 z-10">
        <ul class="py-2">
            <li><a href="" class="block px-4 py-2 hover:bg-gray-200">Owners</a></li>
            <li><a href="" class="block px-4 py-2 hover:bg-gray-200">Pasien</a></li>
        </ul>
    </div>
</div>
<?php /**PATH D:\VETLINK\VetLink-app\resources\views/components/client-dropdown.blade.php ENDPATH**/ ?>