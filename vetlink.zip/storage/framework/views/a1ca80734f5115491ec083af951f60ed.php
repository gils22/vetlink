    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Data Doctors</title>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    </head>

    <body class="bg-gray-100">
        <div class="container mx-auto py-12">
            <h1 class="text-3xl font-bold text-center mb-8">Data Doctors</h1>
            <div class="bg-white rounded-lg shadow-lg p-12">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="bg-white border-2 border-gray-200 rounded-lg p-6 shadow-md hover:shadow-lg transition transform hover:-translate-y-1">
                            <div class="flex flex-col items-center">
                                <img src="<?php echo e(asset($doctor->profile_image ?? 'images/default-avatar.png')); ?>"
                                    alt="Doctor Avatar" class="w-24 h-24 rounded-full mb-4 shadow-lg bg-gray-200">
                                <h3 class="text-lg font-bold text-gray-700"><?php echo e($doctor->name); ?></h3>
                                <p class="text-gray-500 text-sm"><?php echo e($doctor->role); ?></p>
                                <p class="text-gray-400 text-sm"><?php echo e($doctor->email); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </body>

    </html>
<?php /**PATH D:\VETLINK\VetLink-app\resources\views/doctors/index.blade.php ENDPATH**/ ?>