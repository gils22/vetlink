import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js'],
            refresh: true,
        }),
    ],
    server: {
        host: '0.0.0.0', // Mengijinkan akses dari semua alamat IP
        port: 5173, // Port default untuk Vite
        hmr: {
            host: '192.168.0.120', // Ganti dengan IP lokal laptop Anda
        },
    },
});
